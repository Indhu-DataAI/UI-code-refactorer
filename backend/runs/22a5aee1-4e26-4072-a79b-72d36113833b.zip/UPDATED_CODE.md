Here is the updated HTML code for the submit button with the new color classes:

```html
<button type="submit" className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Generate Campaign</button>
```