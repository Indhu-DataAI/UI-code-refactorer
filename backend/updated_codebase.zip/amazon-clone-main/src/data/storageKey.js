function getStorageKey (uid) { return `charles_amazon_clone_user_${uid}` }
export default getStorageKey;