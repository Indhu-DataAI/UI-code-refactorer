const socials = {
  github: 'https://github.com/okoyecharles',
  portfolio: 'https://okoyecharles.com',
  gmail: 'mailto:okoyecharles509@gmail.com'
};

export default socials;